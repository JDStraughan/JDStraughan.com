<?php

return array(
    'password_confirm' => array(
        'matches' => 'The password fields did not match.',
    ),
);