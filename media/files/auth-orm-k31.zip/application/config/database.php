<?php defined('SYSPATH') or die('No direct access allowed.');

return array
(
	'default' => array(
		'type'       => 'mysql',
		'connection' => array(
			'hostname'   => '127.0.0.1',
			'username'   => 'user',
			'password'   => 'password',
			'persistent' => FALSE,
			'database'   => 'example31',
		),
		'table_prefix' => '',
		'charset'      => 'utf8',
		'caching'      => FALSE,
		'profiling'    => TRUE,
	)
);